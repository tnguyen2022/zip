---
title: "Contact"
date: 2018-01-29T15:00:36-05:00
draft: false
type: Contact
---

# Contact Information

### Postal Address:

424 Hurtig Hall

Northeastern University

360 Huntington Avenue

Boston, MA 02115-5000


### Phone Numbers:

Sunny: 617.373.4818

Lab: 617.373.2800

617.373.2868

### Email:

[See People Page](google.com)

### Campus Map:

[Click here to see the map](www.northeastern.edu/campusmap)

Google Maps:

(map)

### Direction for walking from nearby T Station:

#### From Orange Line: Mass Ave (The closest stop)

[image](../../img/mass-hurtig.png)

Exit the station to Gainsborough St.

After you go down stair, take the left on Gainsborough St.

Take the second right. The Hurtig Hall is on your right.

See this map for more detail

#### From Orange Line: Ruggles Station

Exit the station to Forthy Street.

Then turn right to a path behind the library.

Take the third left. The Hurtig Hall is on your right.

See this map for more detail

#### From Green Line: Northeastern University

Exit the train, and turn right if you are on the train to Heat Street or turn left if you are on the train to Lechmere.

Then turn right at the end of road, be careful when crossing the road.

walk staight to Ell Hall. Then turn left, and turn right, and turn left, and pass Mugar Life Sciences Building.

Take the first right. Hurtig Hall is on your left.

See this map for more detail
