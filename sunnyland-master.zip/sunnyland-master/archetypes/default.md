---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
menu: main
---

